﻿def say_hello():
    return "Hello from Lambda Layer!"
